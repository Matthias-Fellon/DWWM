Copyright (c) 2020, Jérémy Landes <jeremy@studiotriple.fr>, Alex Slobzheninov, George Triantafyllakos
with Reserved Font Names "Murmure", "Le Murmure".
