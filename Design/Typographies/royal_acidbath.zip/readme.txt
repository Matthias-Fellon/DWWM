TrueTypeFont: Royal Acidbath
Dennis Ludlow 2001 all rights reserved
Sharkshock Productions

Hey there everyone. This font might just be music to your ears. This is my first 2 part series
 typeface. This does not look good in all caps all you Instant Message people. For that, i
 would use the regular version. As always, feel free to re-distribute for non-commercial use
 of course.

check out my graphic archive at www.sharkshock.uni.cc
                                  "because boring design SUCKS!"