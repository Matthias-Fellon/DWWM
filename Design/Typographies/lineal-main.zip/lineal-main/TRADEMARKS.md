Lineal is a trademark of Frank Adebiaye (fadebiaye@gmail.com) (2010-2023).
